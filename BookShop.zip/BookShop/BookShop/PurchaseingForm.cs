﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BookShop.Model;
using BookShop.Business;

namespace BookShop
{
    public partial class PurchaseingForm : Form
    {
        public PurchaseingForm()
        {
            InitializeComponent();
        }

        private void SaveRecordbutton1_Click(object sender, EventArgs e)
        {
            if(IsValidaet())
            {
            PurchasingBookModel pbm = new PurchasingBookModel()
            {
              ShopName = ShopNametextBox1.Text.Trim(),
              ParsonName = PorsonNametextBox2.Text.Trim(),
              ParsonMobile = PorsonMobiletextBox3.Text.Trim(),
              BookName = BookNametextBox4.Text.Trim(),
              Quantity = Convert.ToInt32(QuantitytextBox5.Text.Trim()),
              PriceOfBook = Convert.ToDecimal(PriceOfBooktextBox6.Text.Trim()),
              PurchasingDate = ShopingDatedateTimePicker1.Value
            };
            PurchasingBookBusiness.AddPurchasingBook(pbm);
            MessageBox.Show("Add Successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private bool IsValidaet()
        {
            if (ShopNametextBox1.Text.Trim() == String.Empty)
            {
                msg("Enter Shop Name", ShopNametextBox1);
                return false;
            }
            if (PorsonNametextBox2.Text.Trim() == String.Empty)
            {
                msg("Enter Parson Name", PorsonNametextBox2);
                return false;
            }

            if (PorsonMobiletextBox3.Text.Trim() == String.Empty)
            {
                msg("Enter Parson Mibile", PorsonMobiletextBox3);
                return false;
            }

            if (BookNametextBox4.Text.Trim() == String.Empty)
            {
                msg("Enter Books Name", BookNametextBox4);
                return false;
            }

            if (QuantitytextBox5.Text.Trim() == String.Empty)
            {
                msg("Enter Quantity", QuantitytextBox5);
                return false;
            }

            if (PriceOfBooktextBox6.Text.Trim() == String.Empty)
            {
                msg("Enter Unit Price", PriceOfBooktextBox6);
                return false;
            }

            if (ShopingDatedateTimePicker1.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Select Date", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ShopingDatedateTimePicker1.Focus();
                return false;
            }
            else {
                return true;
            }
        }

        private void msg(String msg, TextBox textbox)
        {
            MessageBox.Show(msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            textbox.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //ShopNametextBox1.Clear();

        }

        
    }
}
