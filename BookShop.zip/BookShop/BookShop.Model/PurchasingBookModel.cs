﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookShop.Model
{
   public class PurchasingBookModel
    {
       public String ShopName  { get; set; }
        public String ParsonName { get; set; }
        public String ParsonMobile { get; set; }
        public String BookName { get; set; }
        public Decimal PriceOfBook { get; set; }
        public int Quantity { get; set; }
        public DateTime PurchasingDate { get; set; }

    }
}
