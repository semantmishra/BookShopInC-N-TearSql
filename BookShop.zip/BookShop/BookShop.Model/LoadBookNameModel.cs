﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookShop.Model
{
   public class LoadBookNameModel
    {
        public String BookName { get; set; }
    }
}
