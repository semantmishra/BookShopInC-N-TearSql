﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BookShop.Business;

namespace BookShop
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void PurchasingBookstoolStripButton4_Click(object sender, EventArgs e)
        {
            PurchasingBook();
       }

        private static void PurchasingBook()
        {
            PurchaseingForm purchaseingForm = new PurchaseingForm();
            purchaseingForm.ShowDialog();
        }

        private void PurchasingRecordsToolStripButton2_Click(object sender, EventArgs e)
        {
            PurchasingRecord();
        }

        private static void PurchasingRecord()
        {
            PurchasingRecordsForm purchasingRecordsForm = new PurchasingRecordsForm();
            purchasingRecordsForm.ShowDialog();
        }

        private void SellingBooksToolStripButton3_Click(object sender, EventArgs e)
        {
            SellingBooks();
        }

        private static void SellingBooks()
        {
            SellingBooksForm sellingBooksForm = new SellingBooksForm();
            sellingBooksForm.ShowDialog();
        }

        private void SellingRecordsToolStripButton1_Click(object sender, EventArgs e)
        {
            SellingRecorffomr();
        }

        private static void SellingRecorffomr()
        {
            SellingRecordsForm srf = new SellingRecordsForm();
            srf.Text = "Selling Records";
            srf.ShowDialog();
        }

        private void sellingRecordsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SellingRecorffomr();
        }

        private void purchasingRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PurchasingRecord();
        }

        private void sellingBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SellingBooks();
        }

        private void purchasingBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PurchasingBook();
        }

        private void AboutShopToolStripButton5_Click(object sender, EventArgs e)
        {
            Abaut a = new Abaut();
            a.ShowDialog();
        }       
    }
}
