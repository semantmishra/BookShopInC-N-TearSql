﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System .Data .SqlClient;
using System.Configuration;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Data.SqlClient;


namespace BookShop.Data
{
     public class PurchasRecordDB
    {
         //public static DataTable GetPurchasingRecords()
         //{
         //    DataTable dtPurchsingRecord = new DataTable();

         //    string ConnString = ConfigurationManager.ConnectionStrings["BookShopDB"].ConnectionString;
         //    using (SqlConnection conn = new SqlConnection(ConnString))
         //    {
         //        using (SqlCommand cmd = new SqlCommand("GetPurchasingRecord", conn))
         //        {
         //            cmd.CommandType = CommandType.StoredProcedure;
         //            conn.Open();
         //            using (SqlDataReader reader = cmd.ExecuteReader())
         //            {
         //                dtPurchsingRecord.Load(reader);
         //            }
         //        }
         //    }
         //    return dtPurchsingRecord;
         //}

    }
}
