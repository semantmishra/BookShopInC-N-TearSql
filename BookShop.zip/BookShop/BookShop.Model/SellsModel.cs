﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookShop.Model
{
   public class SellsModel
    {
        public String  ShopName { get; set; }
        public String  BuyingParson { get; set; }
        public String  BuyingParsonMobile { get; set; }
        public String Seller { get; set; }
        public String  BooksName { get; set; }
        public int Quantity { get; set; }
        public Decimal  PriseOfOneBook { get; set; }
        public Decimal  PriceOfAllBook { get; set; }
        public DateTime  SellingDate { get; set; }
    }
}
