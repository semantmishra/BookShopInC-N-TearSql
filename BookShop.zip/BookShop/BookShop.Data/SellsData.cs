﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BookShop.Model;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
namespace BookShop.Data
{
    public class SellsData
    {
        public static void AddSellsRecord(SellsModel sellsModel)
        {
            String ConnString = ConfigurationManager.ConnectionStrings["BookShopDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(ConnString)) 
            {
                using (SqlCommand cmd = new SqlCommand("usp_Sells_AddNewBooks",conn))
                {
                    conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ShopName", sellsModel.ShopName);
                    cmd.Parameters.AddWithValue("@BuyingParson", sellsModel.BuyingParson);
                    cmd.Parameters.AddWithValue("@BuyingParsonMobile", sellsModel.BuyingParsonMobile);
                    cmd.Parameters.AddWithValue("@Seller", sellsModel.Seller);
                    cmd.Parameters.AddWithValue("@BooksName", sellsModel.BooksName);
                    cmd.Parameters.AddWithValue("@Quantity", sellsModel.Quantity);
                    cmd.Parameters.AddWithValue("@PriseOfOneBook", sellsModel.PriseOfOneBook);
                    cmd.Parameters.AddWithValue("@PriceOfAllBook", sellsModel.PriceOfAllBook);
                    cmd.Parameters.AddWithValue("@SellingDate", sellsModel.SellingDate);
                    cmd.ExecuteNonQuery();
                }
            }

        }


        public static DataTable ShowSellsRecord() 
        {
            
            using (DataTable dt = new DataTable())
            {
                 String ConnString = ConfigurationManager.ConnectionStrings["BookShopDB"].ConnectionString;
                 using (SqlConnection conn = new SqlConnection(ConnString)) 
                 {
                     using (SqlCommand cmd = new SqlCommand("Sells_GetSellsRecords", conn))
                     {
                         conn.Open();
                         using (SqlDataReader reader = cmd.ExecuteReader())
                         {
                             dt.Load(reader);
                         }

                     }
                 
                 }
                 return dt;
            }
            
        }

    }
}
