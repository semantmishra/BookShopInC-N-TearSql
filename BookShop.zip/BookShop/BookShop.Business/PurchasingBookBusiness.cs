﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BookShop.Data;
using BookShop.Model;

namespace BookShop.Business
{
   public  class PurchasingBookBusiness
    {
       public static void AddPurchasingBook(PurchasingBookModel purchasingBookBusiness)
       {
           BookPurchasingDB.purchasingBook(purchasingBookBusiness);
       }
    }
}
