﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using BookShop.Business;
using BookShop.Model;

namespace BookShop
{
    public partial class SellingBooksForm : Form
    {
        public SellingBooksForm()
        {
            InitializeComponent();
        }

        private void SellingBooksForm_Load(object sender, EventArgs e)
        {

            loadBookName();
        }

        public void loadBookName() 
        {
            String ConnString = ConfigurationManager.ConnectionStrings["BookShopDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(ConnString)) 
            {
                using (SqlCommand cmd = new SqlCommand("GetBookName", conn)) 
                {
                    conn.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    BookNameComboBox1.Text = "Select Book";
                    while (dr.Read()) 
                    {
                        BookNameComboBox1.Items.Add(dr["BookName"]);
                    }
                    
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (IsValidate())
            {
                SellsModel sellsmodel = new SellsModel()
                {
                    ShopName = ShopNameTextBox1.Text.Trim(),
                    BuyingParson = BuyingParsomTextBox2.Text.Trim(),
                    BuyingParsonMobile = BuyingParsonMobileTextBox3.Text.Trim(),
                    Seller = SellerTextBox4.Text.Trim(),
                    BooksName = BookNameComboBox1.Text.Trim(),
                    Quantity = Convert.ToInt32( QuantityTtextBox5.Text.Trim()),
                    PriseOfOneBook = Convert.ToDecimal( PriseOfOneBoockTextBox6.Text.Trim()),
                    PriceOfAllBook = Convert.ToDecimal(PriceOfAllBookTextBox7.Text.Trim()),
                    SellingDate = Convert.ToDateTime( dateTimePicker1.Value)
                };
                SellsBusines.SellsAddNew(sellsmodel);
                MessageBox.Show("Data Insert ","SuccesFull", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
           
        }

        private bool IsValidate()
        {

            if (ShopNameTextBox1.Text.Trim() == String.Empty)
            {
                msg("Enter Your Name", ShopNameTextBox1);
                return false;
            }
           

            if (BuyingParsomTextBox2.Text.Trim() == String.Empty)
            {
                msg("Enter Buying Parson", BuyingParsomTextBox2);
                return false;
            }

            if (BuyingParsonMobileTextBox3.Text.Trim() == String.Empty)
            {
                msg("Enter Buying Parson Mobile", BuyingParsonMobileTextBox3);
                return false;
            }

            if (SellerTextBox4.Text.Trim() == String.Empty)
            {
                msg("Enter Seller Name", SellerTextBox4);
                return false;
            }

            if (BookNameComboBox1.Text.Trim() == String.Empty)
            {
                MessageBox.Show("Select Books Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                BookNameComboBox1.Focus();
                
                return false;
            }

            if (QuantityTtextBox5.Text.Trim() == String.Empty)
            {
                msg("Enter Quantity", QuantityTtextBox5);
                return false;
            }

            if (PriseOfOneBoockTextBox6.Text.Trim() == String.Empty)
            {
                msg("Enter Prise Of One Book", PriseOfOneBoockTextBox6);
                return false;
            }
            if (PriceOfAllBookTextBox7.Text.Trim() == String.Empty)
            {
                msg("Enter Price All Book", PriceOfAllBookTextBox7);
                return false;
            }
            else
            {
                return true;
            }
        }

        private void msg(String msg, TextBox textbox)
        {
                MessageBox.Show(msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textbox.Focus();
        }
    }
}
