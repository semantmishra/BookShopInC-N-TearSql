﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BookShop.Business;
using System.Data.SqlClient;
using System.Configuration;

namespace BookShop
{
    public partial class PurchasingRecordsForm : Form
    {
        public PurchasingRecordsForm()
        {
            InitializeComponent();
        }

        private void PurchasingRecordsForm_Load(object sender, EventArgs e)
        {
           // dataGridView1.DataSource = PurchasRecordShow();
            Show("GetPurchasingRecord", dataGridView1);
          }

        private void Show(string p, DataGridView dataGridView)
        {
            DataTable dtPurchsingRecord = new DataTable();

            string ConnString = ConfigurationManager.ConnectionStrings["BookShopDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(ConnString))
            {
                using (SqlCommand cmd = new SqlCommand(p, conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        dtPurchsingRecord.Load(reader);

                    }
                }
            }
            dataGridView.DataSource = dtPurchsingRecord;
            // return dtPurchsingRecord;
        }



        
        //public static DataTable PurchasRecordShow()
        //{
        //    DataTable PurchasRecordsShow = PurchasRecordBusiness.PurchasRecords();
        //    return PurchasRecordsShow;
        //}

    }
}
