﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BookShop.Model;
using BookShop.Data;
using System.Data;

namespace BookShop.Business
{
   public class SellsBusines
    {
       public static void SellsAddNew(SellsModel sellsModel)
       {
           SellsData.AddSellsRecord(sellsModel);
       }

       public static DataTable SellsShowRecord() 
       {
           DataTable dt = SellsData.ShowSellsRecord();
           return dt;
       }
    }
}
