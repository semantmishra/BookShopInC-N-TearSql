﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BookShop.Data;
using System.Data;


namespace BookShop.Business
{
   public class PurchasRecordBusiness
    {
       //public static DataTable PurchasRecords()
       //{ 
       //    DataTable dtPurchas    =  PurchasRecordDB.GetPurchasingRecords();
       //    return dtPurchas;
       //}
    }
}
