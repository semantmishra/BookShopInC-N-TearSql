﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using BookShop.Model;

namespace BookShop.Data
{
    public class BookPurchasingDB
    {
        public static void purchasingBook(PurchasingBookModel purchasingBookModel)
        {
            String connString = ConfigurationManager.ConnectionStrings["BookShopDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {

                SqlCommand cmd = new SqlCommand("purchasNewBookRecords", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ShopName", purchasingBookModel.ShopName);
                cmd.Parameters.AddWithValue("@ParsonName", purchasingBookModel.ParsonName);
                cmd.Parameters.AddWithValue("@ParsonMobile", purchasingBookModel.ParsonMobile);
                cmd.Parameters.AddWithValue("@BookName", purchasingBookModel.BookName);
                cmd.Parameters.AddWithValue("@PriceOfBook", purchasingBookModel.PriceOfBook);
                cmd.Parameters.AddWithValue("@Quantity", purchasingBookModel.Quantity);
                cmd.Parameters.AddWithValue("@PurchasingDate", purchasingBookModel.PurchasingDate);
                conn.Open();
                cmd.ExecuteNonQuery();

            }

        }
    }
}
