﻿namespace BookShop
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.SellingRecordsToolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.PurchasingRecordsToolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.SellingBooksToolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.PurchasingBookstoolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.AboutShopToolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.sellingRecordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchasingRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sellingBooksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchasingBookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutShopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.toolStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SellingRecordsToolStripButton1,
            this.toolStripSeparator1,
            this.PurchasingRecordsToolStripButton2,
            this.toolStripSeparator2,
            this.SellingBooksToolStripButton3,
            this.toolStripSeparator3,
            this.PurchasingBookstoolStripButton4,
            this.toolStripSeparator4,
            this.AboutShopToolStripButton5});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.toolStrip1.Size = new System.Drawing.Size(890, 43);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // SellingRecordsToolStripButton1
            // 
            this.SellingRecordsToolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("SellingRecordsToolStripButton1.Image")));
            this.SellingRecordsToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SellingRecordsToolStripButton1.Name = "SellingRecordsToolStripButton1";
            this.SellingRecordsToolStripButton1.Size = new System.Drawing.Size(115, 40);
            this.SellingRecordsToolStripButton1.Text = "Selling Records";
            this.SellingRecordsToolStripButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.SellingRecordsToolStripButton1.Click += new System.EventHandler(this.SellingRecordsToolStripButton1_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 43);
            // 
            // PurchasingRecordsToolStripButton2
            // 
            this.PurchasingRecordsToolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("PurchasingRecordsToolStripButton2.Image")));
            this.PurchasingRecordsToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.PurchasingRecordsToolStripButton2.Name = "PurchasingRecordsToolStripButton2";
            this.PurchasingRecordsToolStripButton2.Size = new System.Drawing.Size(141, 40);
            this.PurchasingRecordsToolStripButton2.Text = "Purchasing Records";
            this.PurchasingRecordsToolStripButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PurchasingRecordsToolStripButton2.Click += new System.EventHandler(this.PurchasingRecordsToolStripButton2_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 43);
            // 
            // SellingBooksToolStripButton3
            // 
            this.SellingBooksToolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("SellingBooksToolStripButton3.Image")));
            this.SellingBooksToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SellingBooksToolStripButton3.Name = "SellingBooksToolStripButton3";
            this.SellingBooksToolStripButton3.Size = new System.Drawing.Size(102, 40);
            this.SellingBooksToolStripButton3.Text = "Selling Books";
            this.SellingBooksToolStripButton3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.SellingBooksToolStripButton3.Click += new System.EventHandler(this.SellingBooksToolStripButton3_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 43);
            // 
            // PurchasingBookstoolStripButton4
            // 
            this.PurchasingBookstoolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("PurchasingBookstoolStripButton4.Image")));
            this.PurchasingBookstoolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.PurchasingBookstoolStripButton4.Name = "PurchasingBookstoolStripButton4";
            this.PurchasingBookstoolStripButton4.Size = new System.Drawing.Size(132, 40);
            this.PurchasingBookstoolStripButton4.Text = "Purchasing Books ";
            this.PurchasingBookstoolStripButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.PurchasingBookstoolStripButton4.Click += new System.EventHandler(this.PurchasingBookstoolStripButton4_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 43);
            // 
            // AboutShopToolStripButton5
            // 
            this.AboutShopToolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("AboutShopToolStripButton5.Image")));
            this.AboutShopToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AboutShopToolStripButton5.Name = "AboutShopToolStripButton5";
            this.AboutShopToolStripButton5.Size = new System.Drawing.Size(92, 40);
            this.AboutShopToolStripButton5.Text = "About Shop";
            this.AboutShopToolStripButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.AboutShopToolStripButton5.Click += new System.EventHandler(this.AboutShopToolStripButton5_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sellingRecordsToolStripMenuItem,
            this.purchasingRecordToolStripMenuItem,
            this.sellingBooksToolStripMenuItem,
            this.purchasingBookToolStripMenuItem,
            this.aboutShopToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(201, 124);
            // 
            // sellingRecordsToolStripMenuItem
            // 
            this.sellingRecordsToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sellingRecordsToolStripMenuItem.Image")));
            this.sellingRecordsToolStripMenuItem.Name = "sellingRecordsToolStripMenuItem";
            this.sellingRecordsToolStripMenuItem.Size = new System.Drawing.Size(200, 24);
            this.sellingRecordsToolStripMenuItem.Text = "Selling Records";
            this.sellingRecordsToolStripMenuItem.Click += new System.EventHandler(this.sellingRecordsToolStripMenuItem_Click);
            // 
            // purchasingRecordToolStripMenuItem
            // 
            this.purchasingRecordToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("purchasingRecordToolStripMenuItem.Image")));
            this.purchasingRecordToolStripMenuItem.Name = "purchasingRecordToolStripMenuItem";
            this.purchasingRecordToolStripMenuItem.Size = new System.Drawing.Size(200, 24);
            this.purchasingRecordToolStripMenuItem.Text = "Purchasing Record";
            this.purchasingRecordToolStripMenuItem.Click += new System.EventHandler(this.purchasingRecordToolStripMenuItem_Click);
            // 
            // sellingBooksToolStripMenuItem
            // 
            this.sellingBooksToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sellingBooksToolStripMenuItem.Image")));
            this.sellingBooksToolStripMenuItem.Name = "sellingBooksToolStripMenuItem";
            this.sellingBooksToolStripMenuItem.Size = new System.Drawing.Size(200, 24);
            this.sellingBooksToolStripMenuItem.Text = "Selling Books";
            this.sellingBooksToolStripMenuItem.Click += new System.EventHandler(this.sellingBooksToolStripMenuItem_Click);
            // 
            // purchasingBookToolStripMenuItem
            // 
            this.purchasingBookToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("purchasingBookToolStripMenuItem.Image")));
            this.purchasingBookToolStripMenuItem.Name = "purchasingBookToolStripMenuItem";
            this.purchasingBookToolStripMenuItem.Size = new System.Drawing.Size(200, 24);
            this.purchasingBookToolStripMenuItem.Text = "Purchasing Book";
            this.purchasingBookToolStripMenuItem.Click += new System.EventHandler(this.purchasingBookToolStripMenuItem_Click);
            // 
            // aboutShopToolStripMenuItem
            // 
            this.aboutShopToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("aboutShopToolStripMenuItem.Image")));
            this.aboutShopToolStripMenuItem.Name = "aboutShopToolStripMenuItem";
            this.aboutShopToolStripMenuItem.Size = new System.Drawing.Size(200, 24);
            this.aboutShopToolStripMenuItem.Text = "About Shop";
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(890, 371);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.toolStrip1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Home";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton SellingRecordsToolStripButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton PurchasingRecordsToolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton SellingBooksToolStripButton3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton PurchasingBookstoolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton AboutShopToolStripButton5;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem sellingRecordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purchasingRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sellingBooksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purchasingBookToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutShopToolStripMenuItem;
    }
}

